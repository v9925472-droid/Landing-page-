const button = document.getElementById("surpriseBtn");
const surpriseMessage = document.getElementById("surpriseMessage");

button.addEventListener("click", () => {
    surpriseMessage.classList.remove("hidden");
    button.textContent = "🎂 Have an Awesome Birthday! 🎂";
});
